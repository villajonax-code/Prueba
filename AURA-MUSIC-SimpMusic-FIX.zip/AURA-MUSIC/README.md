# AURA Music — SimpMusic engine

Esta versión conserva los archivos originales de AURA como referencia, pero el APK se construye sobre el código fuente de **SimpMusic v2.2.0**, en lugar del WebView/YouTube API de la versión anterior.

## Qué cambia

- Motor nativo Kotlin + Compose Multiplatform de SimpMusic.
- Media3/ExoPlayer para reproducción Android.
- Cliente YouTube Music de SimpMusic.
- Ktor + Kotlin Serialization.
- Room + DataStore para persistencia.
- QuickJS para el procesamiento del reproductor de YouTube.
- Reproducción en segundo plano y MediaSession.
- Letras, cola, playlists, caché y descargas según las capacidades de SimpMusic.
- Variante FOSS: sin Sentry ni Google Cast propietario.
- Nombre de aplicación: **AURA Music**.

SimpMusic documenta esta arquitectura y sus módulos en su repositorio oficial.

## Compilación

El workflow `.github/workflows/build-apk.yml` descarga automáticamente SimpMusic v2.2.0 durante la compilación y genera `AURA-Music-simpmusic.apk`.

El APK **no descarga librerías ejecutables durante el primer arranque**: Kotlin/Compose/Media3/etc. deben estar dentro del APK. Lo que sí se inicializa/descarga en ejecución son datos y cachés necesarios para streaming y funciones online.

SimpMusic requiere Android 8.0/API 26 o posterior y aproximadamente 500 MB de espacio libre recomendado, además de lo que se guarde en caché.

## Licencia

SimpMusic está publicado bajo GPL-3.0. Esta distribución derivada conserva esa licencia. citeturn5search2turn5search4
