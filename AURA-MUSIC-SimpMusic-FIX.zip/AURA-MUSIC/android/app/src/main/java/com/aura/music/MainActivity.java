package com.aura.music;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.Uri;
import android.app.NotificationManager;
import android.app.PictureInPictureParams;
import android.content.res.Configuration;
import android.util.Rational;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Aloja la app web local. El origen https permite que los iframes de YouTube reciban un Referer válido. */
public class MainActivity extends Activity {
    private static final String ORIGIN = "https://aura.local/";
    private static final int PICK = 7;
    private WebView web;
    private ValueCallback<Uri[]> chooserCb;
    private volatile boolean pipOk;

    private final BroadcastReceiver actions = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getStringExtra("a");
            if (a != null && web != null) web.evaluateJavascript("window.AURA&&AURA.act('" + a.replaceAll("[^a-z]", "") + "')", null);
        }
    };

    /** Puente JS → nativo: solo informa del estado para la notificación. */
    public class Bridge {
        @JavascriptInterface public void state(String title, String artist, boolean playing, String cover) {
            PlaybackService.update(MainActivity.this, title, artist, playing, cover);
        }
        /** Estado de las notificaciones (para el diagnóstico de la app). */
        @JavascriptInterface public String diag() {
            NotificationManager nm = getSystemService(NotificationManager.class);
            return "{\"sdk\":" + Build.VERSION.SDK_INT + ",\"enabled\":" + nm.areNotificationsEnabled() + ",\"perm\":" + notifOk()
                + ",\"service\":" + PlaybackService.running() + ",\"error\":" + JSONObject.quote(PlaybackService.lastError) + "}";
        }
        @JavascriptInterface public void test() { PlaybackService.update(MainActivity.this, "AURA Music", "Notificación de prueba", true, ""); }
        /** La app avisa si hay un video de YouTube sonando: al salir se muestra en ventana flotante (imagen en imagen). */
        @JavascriptInterface public void pip(boolean on) { pipOk = on; }
        @JavascriptInterface public boolean notifOk() {
            return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
        @JavascriptInterface public void notifSettings() {
            runOnUiThread(new Runnable() { @Override public void run() {
                try { startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())); } catch (Exception ignored) { }
            } });
        }
        @JavascriptInterface public void batterySettings() {
            runOnUiThread(new Runnable() { @Override public void run() {
                try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception ignored) { }
            } });
        }
        /** Solo abre la consola de Google Cloud, para obtener la clave gratuita de YouTube. */
        @JavascriptInterface public void openUrl(final String u) {
            if (u == null || !u.startsWith("https://console.cloud.google.com/")) return;
            runOnUiThread(new Runnable() { @Override public void run() {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception ignored) { }
            } });
        }
    }

    private String readAsset(String name) throws Exception {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient() {
            // Bloquea navegar fuera de la app; los iframes (YouTube) sí pueden cargar.
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return r.isForMainFrame(); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    .putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "text/*", "application/json", "application/octet-stream", "application/zip", "application/x-zip-compressed"});
                try { startActivityForResult(i, PICK); } catch (Exception e) { chooserCb = null; return false; }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AuraNative");
        IntentFilter f = new IntentFilter(PlaybackService.ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(actions, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(actions, f);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        try {
            web.loadUrl("file:///android_asset/index.html");
        } catch (Exception e) {
            web.loadData("No se pudo abrir AURA Music.", "text/plain", "UTF-8");
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req != PICK || chooserCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK && d != null) {
            if (d.getClipData() != null) {
                out = new Uri[d.getClipData().getItemCount()];
                for (int k = 0; k < out.length; k++) out[k] = d.getClipData().getItemAt(k).getUri();
            } else if (d.getData() != null) out = new Uri[]{d.getData()};
        }
        chooserCb.onReceiveValue(out);
        chooserCb = null;
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("window.AURA&&AURA.back()", new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) { if (!"true".equals(v)) MainActivity.super.onBackPressed(); }
        });
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (pipOk && Build.VERSION.SDK_INT >= 26) {
            try { enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9)).build()); } catch (Exception ignored) { }
        }
    }

    @Override public void onPictureInPictureModeChanged(boolean in, Configuration c) {
        super.onPictureInPictureModeChanged(in, c);
        if (web != null) web.evaluateJavascript("window.AURA&&AURA.pip(" + in + ")", null);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(actions); } catch (Exception ignored) { }
        stopService(new Intent(this, PlaybackService.class));
        super.onDestroy();
    }
}
