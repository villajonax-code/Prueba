package com.aura.music;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Base64;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Servicio en primer plano: mantiene viva la reproducción, muestra la notificación multimedia
 * (con portada) y expone una MediaSession para Bluetooth y pantalla de bloqueo.
 */
public class PlaybackService extends Service {
    static final String CH = "aura_play", ACTION = "com.aura.music.ACT";
    private static PlaybackService inst;
    static volatile String lastError = "";
    static boolean running() { return inst != null; }
    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaSession session;
    private String title = "", artist = "", coverKey = "";
    private boolean playing;
    private Bitmap art;
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    public static void update(android.content.Context c, final String t, final String a, final boolean p, final String cover) {
        final PlaybackService s = inst;
        if (s != null) {
            s.main.post(new Runnable() { @Override public void run() { s.show(t, a, p, cover); } });
            return;
        }
        try { c.startForegroundService(new Intent(c, PlaybackService.class).putExtra("t", t).putExtra("a", a).putExtra("p", p).putExtra("c", cover)); }
        catch (Exception e) { lastError = "start: " + e; }
    }

    @Override public void onCreate() {
        super.onCreate();
        inst = this;
        session = new MediaSession(this, "AURA");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { send("toggle"); }
            @Override public void onPause() { send("toggle"); }
            @Override public void onSkipToNext() { send("next"); }
            @Override public void onSkipToPrevious() { send("prev"); }
        });
        session.setActive(true);
    }

    @Override public int onStartCommand(Intent i, int f, int id) {
        if (i == null) { stopSelf(); return START_NOT_STICKY; }
        show(i.getStringExtra("t"), i.getStringExtra("a"), i.getBooleanExtra("p", false), i.getStringExtra("c"));
        return START_NOT_STICKY;
    }

    private void send(String key) { sendBroadcast(new Intent(ACTION).setPackage(getPackageName()).putExtra("a", key)); }

    private Notification.Action act(String name, int icon, String key) {
        PendingIntent pi = PendingIntent.getBroadcast(this, key.hashCode(),
            new Intent(ACTION).setPackage(getPackageName()).putExtra("a", key), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), name, pi).build();
    }

    void show(String t, String a, boolean p, String cover) {
        title = t == null ? "" : t; artist = a == null ? "" : a; playing = p;
        if (cover != null && !cover.equals(coverKey)) { coverKey = cover; art = null; loadCover(cover); }
        render();
    }

    /** Carga la portada (data: local o https) fuera del hilo principal. */
    private void loadCover(final String src) {
        new Thread(new Runnable() { @Override public void run() {
            Bitmap b = null;
            try {
                if (src.startsWith("data:")) {
                    byte[] d = Base64.decode(src.substring(src.indexOf(',') + 1), Base64.DEFAULT);
                    b = BitmapFactory.decodeByteArray(d, 0, d.length);
                } else if (src.startsWith("https://")) {
                    HttpURLConnection con = (HttpURLConnection) new URL(src).openConnection();
                    con.setConnectTimeout(8000); con.setReadTimeout(8000);
                    b = BitmapFactory.decodeStream(con.getInputStream());
                    con.disconnect();
                }
            } catch (Exception ignored) { }
            final Bitmap fb = b;
            main.post(new Runnable() { @Override public void run() { if (src.equals(coverKey)) { art = fb; render(); } } });
        } }).start();
    }

    /** Mantiene CPU y Wi-Fi despiertos mientras suena, para que no se corte con la pantalla apagada. */
    private void hold(boolean on) {
        try {
            if (on) {
                if (wake == null) { wake = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aura:play"); wake.setReferenceCounted(false); }
                if (wifi == null) { wifi = ((WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE)).createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "aura:wifi"); wifi.setReferenceCounted(false); }
                if (!wake.isHeld()) wake.acquire(6 * 60 * 60 * 1000L);
                if (!wifi.isHeld()) wifi.acquire();
            } else {
                if (wake != null && wake.isHeld()) wake.release();
                if (wifi != null && wifi.isHeld()) wifi.release();
            }
        } catch (Exception ignored) { }
    }

    private void render() {
        hold(playing);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Reproducción", NotificationManager.IMPORTANCE_LOW));
        MediaMetadata.Builder md = new MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title).putString(MediaMetadata.METADATA_KEY_ARTIST, artist);
        if (art != null) md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art);
        session.setMetadata(md.build());
        session.setPlaybackState(new PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS)
            .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build());
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder nb = new Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(artist)
            .setContentIntent(open).setOngoing(playing).setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(act("Anterior", android.R.drawable.ic_media_previous, "prev"))
            .addAction(act(playing ? "Pausa" : "Reproducir", playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, "toggle"))
            .addAction(act("Siguiente", android.R.drawable.ic_media_next, "next"))
            .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        if (art != null) nb.setLargeIcon(art);
        Notification n = nb.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(1, n);
            lastError = "";
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName() + ": " + e.getMessage();
            try { nm.notify(1, n); } catch (Exception e2) { lastError += " | notify: " + e2.getMessage(); }
        }
    }

    @Override public void onDestroy() { hold(false); inst = null; if (session != null) session.release(); super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }
}
