"""Une src/index.html + src/styles.css + src/app.js en un único index.html autocontenido (el que usa la app)."""
import pathlib
r = pathlib.Path(__file__).resolve().parent.parent
h = (r / "src/index.html").read_text(encoding="utf-8")
h = h.replace("<link rel=\"stylesheet\" href=\"styles.css\">", "<style>\n" + (r / "src/styles.css").read_text(encoding="utf-8") + "\n</style>")
h = h.replace("<script src=\"app.js\"></script>", "<script>\n" + (r / "src/app.js").read_text(encoding="utf-8") + "\n</script>")
(r / "index.html").write_text(h, encoding="utf-8")
print("index.html generado:", len(h), "bytes")
