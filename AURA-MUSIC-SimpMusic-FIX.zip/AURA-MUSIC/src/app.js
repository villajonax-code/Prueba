'use strict';
/* AURA Music — local-first. Datos en IndexedDB, nada sale del dispositivo. */
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = s => isFinite(s) ? Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0') : '0:00';
const toast = m => { const t = $('toast'); t.textContent = m; t.className = 'show'; setTimeout(() => t.className = '', 2500); };

/* ---------- Almacenamiento (IndexedDB) ---------- */
const DB = {
  db: null,
  open() {
    return new Promise((ok, no) => {
      const r = indexedDB.open('aura', 1);
      r.onupgradeneeded = () => { r.result.createObjectStore('tracks', { keyPath: 'id' }); r.result.createObjectStore('kv'); };
      r.onsuccess = () => { this.db = r.result; ok(); };
      r.onerror = () => no(r.error);
    });
  },
  tx(store, mode, fn) {
    return new Promise((ok, no) => {
      const t = this.db.transaction(store, mode), res = fn(t.objectStore(store));
      t.oncomplete = () => ok(res.result); t.onerror = () => no(t.error);
    });
  },
  all: () => DB.tx('tracks', 'readonly', s => s.getAll()),
  put: t => DB.tx('tracks', 'readwrite', s => s.put(t)),
  del: id => DB.tx('tracks', 'readwrite', s => s.delete(id)),
  get: k => DB.tx('kv', 'readonly', s => s.get(k)),
  set: (k, v) => DB.tx('kv', 'readwrite', s => s.put(v, k)),
};

/* ---------- Búsqueda difusa ---------- */
const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').trim();
function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
    d[i][j] = Math.min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1));
  return d[a.length][b.length];
}
function tokenScore(q, w) {
  if (w.startsWith(q)) return 1;
  if (w.includes(q) && q.length > 2) return .8;
  const l = lev(q, w.slice(0, q.length + 1)), tol = q.length > 4 ? 2 : 1;
  return q.length > 1 && l <= tol ? .7 - l * .1 : 0;
}
function score(track, query) {
  const qs = norm(query).split(/\s+/).filter(Boolean);
  const fields = [[norm(track.title), 1.2], [norm(track.artist), 1], [norm(track.album), .6]];
  let total = 0;
  for (const q of qs) {
    let best = 0;
    for (const [f, wt] of fields) for (const w of f.split(' ')) best = Math.max(best, tokenScore(q, w) * wt);
    if (!best) return 0;
    total += best;
  }
  return total / qs.length;
}
const search = (list, q) => list.map(t => [t, score(t, q) + (t.yt ? .3 : 0)]).filter(x => x[1] > .3).sort((a, b) => b[1] - a[1]).map(x => x[0]);

/* ---------- Estado ---------- */
const S = { tracks: [], favs: new Set(), history: [], playlists: [], profile: null, web: [], pool: [], jamendoId: '', queue: [], idx: -1, shuffle: false, repeat: 0, tab: 'home', url: null, rate: 1, sleepI: 0, sleepT: null, sleepEnd: false, vol: 1, ytKey: '', trend: null, plOpen: null, stats: { secs: 0, skips: {} },
  cfg: { theme: 'amoled', perf: false, saver: 0, fade: 0, eq: 'flat', eqGains: [0, 0, 0, 0, 0], smart: true, previews: false, accent: 'lime', lrclib: false, hide: [] } };
const VERSION = '0.9.0';
const PF = new Audio(); PF.preload = 'auto'; PF.muted = true; // precarga la siguiente pista remota
const A = [new Audio(), new Audio()]; let audio = A[0], lastT = 0; // A[1] pasa por el ecualizador (solo archivos locales)
const applyRate = () => { A.forEach(e => { e.playbackRate = S.rate; }); try { YTA.p?.setPlaybackRate?.(S.rate); } catch { /* sin YouTube */ } };
const applyVol = () => { A.forEach(e => { e.volume = S.vol; }); YTA.volume = S.vol; };
const saveCfg = () => DB.set('cfg', S.cfg).catch(() => {});
const saveStats = () => DB.set('stats', S.stats).catch(() => {});
const EQ = { bands: [60, 230, 910, 3600, 14000], nodes: null, ctx: null,
  presets: { Flat: [0, 0, 0, 0, 0], Bass: [6, 4, 0, -1, -2], Vocal: [-2, 0, 4, 3, 0], Rock: [4, 2, -1, 2, 4], Pop: [-1, 2, 4, 2, -1], Classical: [3, 2, -1, 2, 3] } };
function initEq() {
  if (EQ.nodes) return EQ.ctx.resume().catch(() => {});
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)(); let prev = c.createMediaElementSource(A[1]);
    EQ.nodes = EQ.bands.map(f => { const n = c.createBiquadFilter(); n.type = 'peaking'; n.frequency.value = f; n.Q.value = 1; prev.connect(n); prev = n; return n; });
    prev.connect(c.destination); EQ.ctx = c; applyEq();
  } catch { toast('El ecualizador no está disponible en este dispositivo.'); }
}
const applyEq = () => EQ.nodes?.forEach((n, i) => { n.gain.value = S.cfg.eqGains[i] || 0; });
const ACCENTS = { lime: ['#c6ff3d', '#3a7d00'], violet: ['#b388ff', '#6a3fd0'], sky: ['#4fc3f7', '#0277bd'], rose: ['#ff6b9d', '#c2185b'], amber: ['#ffb74d', '#b26a00'], mint: ['#5cf2c3', '#00796b'] };
function applyCfg() {
  const th = S.cfg.theme === 'auto' ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'amoled') : S.cfg.theme;
  document.documentElement.dataset.theme = th; document.documentElement.style.setProperty('--ac', (ACCENTS[S.cfg.accent] || ACCENTS.lime)[th === 'light' ? 1 : 0]); document.body.classList.toggle('perf', !!S.cfg.perf || S.cfg.saver === 2);
}
function fadeVol() { // fundido de entrada/salida entre canciones (0–12 s)
  const f = S.cfg.fade; if (!f || !audio.duration) return;
  audio.volume = S.vol * Math.max(0.05, Math.min(1, audio.currentTime / f, (audio.duration - audio.currentTime) / f));
}
const byId = id => S.tracks.find(t => t.id === id) || S.web.find(t => t.id === id) || S.pool.find(t => t.id === id);
const ytOn = () => S.cfg.yt !== false; // el usuario puede apagar YouTube por completo
const playable = t => !!(t && (t.blob || (t.yt && ytOn()) || (t.preview ? S.cfg.previews : (t.stream || t.itunes)))); // las vistas previas de 30 s solo si el usuario las activa
const https = u => typeof u === 'string' && u.startsWith('https://') ? u : null;
const coverCache = new WeakMap();
const coverUrl = t => t.coverBlob ? (coverCache.get(t.coverBlob) || (coverCache.set(t.coverBlob, URL.createObjectURL(t.coverBlob)), coverCache.get(t.coverBlob))) : (S.cfg.saver ? null : https(t.cover));
const similar = (a, b) => (norm(a.artist) === norm(b.artist) ? 3 : 0) + (a.album && a.album === b.album && a.album !== 'Local' ? 2 : 0) + (a.genre && norm(a.genre) === norm(b.genre) ? 2 : 0)
  + (a.year && b.year && Math.abs(a.year - b.year) <= 3 ? 1 : 0) + (a.bpm && b.bpm && Math.abs(a.bpm - b.bpm) <= 12 ? 1 : 0);
function recommend(seed, n = 20) { // similitud local + favoritos + frecuencia − saltos; nada sale del dispositivo
  const hr = new Map(), hh = new Map(), nowH = new Date().getHours();
  S.history.forEach(h => { hr.set(h.id, (hr.get(h.id) || 0) + 1); const d = Math.abs(new Date(h.at).getHours() - nowH); if (Math.min(d, 24 - d) <= 2) hh.set(h.id, (hh.get(h.id) || 0) + 1); });
  return S.tracks.filter(t => t.id !== seed.id && playable(t)).map(t => [t, similar(seed, t) + (S.favs.has(t.id) ? 1 : 0) + Math.min(2, Math.log2(1 + (hr.get(t.id) || 0))) + Math.min(1, (hh.get(t.id) || 0) * 0.5) - Math.min(2, (S.stats.skips[t.id] || 0) * 0.5)])
    .filter(x => x[1] > 0.5).sort((a, b) => b[1] - a[1]).slice(0, n).map(x => x[0]);
}
function smartAppend() {
  const t = cur(); if (!t) return false;
  const ids = recommend(t, 10).map(x => x.id).filter(id => !S.queue.includes(id)); S.queue.push(...ids); return ids.length > 0;
}
/* ---------- YouTube: reproductor oficial incrustado (con su video y anuncios; sin descargar ni extraer audio) ---------- */
const YT_ERR = { 2: 'Enlace de YouTube no válido.', 5: 'YouTube no pudo reproducir este video.', 100: 'El video no existe o es privado.', 101: 'El dueño no permite verlo fuera de YouTube.', 150: 'El dueño no permite verlo fuera de YouTube.', 153: 'YouTube rechazó el reproductor incrustado.' };
const YTA = { // imita la interfaz de <audio> para que el resto del reproductor funcione igual
  p: null, state: -1, error: null, readyState: 4, tick: null,
  get paused() { return this.state !== 1 && this.state !== 3; },
  get currentTime() { return this.p?.getCurrentTime?.() || 0; },
  set currentTime(v) { this.p?.seekTo?.(v, true); },
  get duration() { return this.p?.getDuration?.() || 0; },
  set volume(v) { this.p?.setVolume?.(Math.round(v * 100)); },
  play() { this.p?.playVideo?.(); return Promise.resolve(); },
  pause() { this.p?.pauseVideo?.(); },
  onState(s) {
    this.state = s; clearInterval(this.tick); this.tick = null;
    if (s === 1) this.tick = setInterval(() => { if (audio === this) onTime(); }, 500); // solo mientras suena
    if (s === 0 && audio === this) next(true);
    if (audio === this) { updatePlayer(); saveStats(); }
  },
  load(id) {
    return new Promise((ok, no) => {
      const make = () => {
        if (this.p) { this.p.loadVideoById(id); return ok(); }
        this.p = new window.YT.Player('ytp', { videoId: id, width: '100%', height: '100%', playerVars: { playsinline: 1, rel: 0, autoplay: 1, origin: location.origin },
          events: { onReady: () => { applyVol(); ok(); }, onStateChange: e => this.onState(e.data), onError: e => { this.state = -1; toast(YT_ERR[e.data] || 'Error de YouTube.'); updatePlayer(); } } });
      };
      if (window.YT?.Player) return make();
      window.onYouTubeIframeAPIReady = make;
      if (!$('ytapi')) { const s = document.createElement('script'); s.id = 'ytapi'; s.src = 'https://www.youtube.com/iframe_api'; s.onerror = () => { s.remove(); toast('No se pudo cargar YouTube. ¿Tienes Internet?'); no(); }; document.head.appendChild(s); }
    });
  },
};
const placeYt = () => { // el video debe verse mientras suena: grande en el reproductor, 200×200 en modo mini
  try { window.AuraNative?.pip(audio === YTA && !audio.paused); } catch { /* sin puente nativo */ }
  const y = audio === YTA, full = !$('full').hidden;
  $('ytbox').hidden = !y; $('ytbox').className = full ? 'ytbig' : 'ytmini'; $('ytslot').hidden = !y || !full; $('fArt').hidden = y;
};
const htmlText = s => { const d = document.createElement('textarea'); d.innerHTML = s; return d.value; };
const jsonp = (url, ms = 5000) => new Promise((ok, no) => { // alternativa cuando el servidor no permite CORS
  const cb = '_j' + Math.random().toString(36).slice(2), s = document.createElement('script');
  const done = () => { delete window[cb]; s.remove(); clearTimeout(tm); }, tm = setTimeout(() => { done(); no(new Error('jsonp')); }, ms);
  window[cb] = d => { done(); ok(d); }; s.onerror = () => { done(); no(new Error('jsonp')); };
  s.src = url + (url.includes('?') ? '&' : '?') + 'callback=' + cb; document.head.appendChild(s);
});
const itJson = async url => { try { const r = await fetch(url); if (r.ok) return await r.json(); } catch { /* sin CORS: JSONP */ } return jsonp(url); };
const itunesTrack = x => ({ id: 'i_' + x.trackId, title: x.trackName, artist: x.artistName, album: x.collectionName || 'Sencillo', source: 'itunes', preview: true, itunes: x.trackId,
  cover: (x.artworkUrl100 || '').replace('100x100', '600x600'), stream: https(x.previewUrl), genre: x.primaryGenreName, year: parseInt(x.releaseDate) || undefined, blob: null, plays: 0 });
const addPool = list => { const seen = new Set(S.pool.map(t => t.id)); S.pool = S.pool.concat(list.filter(t => !seen.has(t.id))).slice(-400); };
async function resolvePreview(t) { // pistas de listas (charts) sin audio: pide la vista previa oficial
  try { const d = await itJson('https://itunes.apple.com/lookup?id=' + t.itunes); t.stream = https(d.results?.[0]?.previewUrl) || null; if (t.stream && S.tracks.includes(t)) DB.put(t).catch(() => {}); } catch { /* sin conexión */ }
}
function resolveAny(t) { // identidad sin audio → canción completa (YouTube) o, si el usuario lo permite, vista previa
  if (ytOn() && S.ytKey) return resolveYt(t);
  if (S.cfg.previews) return resolveItunes(t);
  if (!ytOn()) return toast('YouTube está desactivado (Ajustes). Actívalo, permite vistas previas o importa el archivo.');
  toast('Para escuchar canciones completas activa YouTube.'); return ytSetup();
}
async function resolveItunes(t) { // canción identificada sin audio → vista previa oficial de 30 s (sin claves)
  toast('Buscando vista previa…');
  try {
    const r = (await SOURCES.itunes.search(t.artist + ' ' + t.title))[0];
    if (!r) return toast('No encontré esa canción.');
    Object.assign(t, { stream: r.stream, preview: true, itunes: r.itunes, cover: t.cover || r.cover, genre: t.genre || r.genre, year: t.year || r.year });
    await DB.put(t); cur() === t ? load() : playQueue([t.id], 0);
  } catch { toast('No se pudo buscar. ¿Tienes Internet?'); }
}
async function loadCharts() { // Top global de Apple Music (RSS público)
  if (S.charts) return S.charts;
  try {
    const r = await fetch('https://rss.marketingtools.apple.com/api/v2/us/music/most-played/20/songs.json'); if (!r.ok) throw new Error('charts');
    S.charts = ((await r.json()).feed?.results || []).map(x => ({ id: 'i_' + x.id, title: x.name, artist: x.artistName, album: 'Top global', source: 'itunes', preview: true, itunes: +x.id, stream: null, blob: null, plays: 0,
      cover: String(x.artworkUrl100 || '').replace(/\/\d+x\d+(bb)?\./, '/600x600bb.') }));
    addPool(S.charts);
  } catch { S.charts = null; return []; }
  return S.charts;
}
async function fillCharts() { if (!$('charts')) return; const c = await loadCharts(); if ($('charts')) $('charts').innerHTML = c.length ? '<div class="rail">' + c.map(card).join('') + '</div>' : '<small>Sin conexión: no se pueden cargar los éxitos.</small>'; }
const notifState = () => { try { return JSON.parse(window.AuraNative.diag()); } catch { return null; } };
const svg = d => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`;
const ICON = {
  play: svg('M8 5v14l11-7z'), pause: svg('M6 5h4v14H6zM14 5h4v14h-4z'), next: svg('M6 18l8.5-6L6 6v12zm9-12v12h2V6h-2z'), prev: svg('M6 6h2v12H6zm3.5 6l8.5 6V6z'),
  shuffle: svg('M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z'),
  repeat: svg('M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z'),
  heart: svg('M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3zm-4.4 15.55l-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05z'),
  heartOn: svg('M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z'),
  home: svg('M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z'), search: svg('M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z'),
  library: svg('M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 9H9V9h10v2zm-4 4H9v-2h6v2zm4-8H9V5h10v2z'),
  queue: svg('M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z'), lyrics: svg('M4 4h16v2H4zm0 4h16v2H4zm0 4h10v2H4zm0 4h10v2H4z'),
  radio: svg('M3.24 6.15C2.51 6.43 2 7.17 2 8v12c0 1.1.89 2 2 2h16c1.11 0 2-.9 2-2V8c0-1.11-.89-2-2-2H8.3l8.26-3.34L15.88 1 3.24 6.15zM7 20c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm13-8h-2v-2h-2v2H4V8h16v4z'),
  download: svg('M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z'), down: svg('M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z'), plus: svg('M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z'),
  clock: svg('M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z'),
  speed: svg('M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44zm-9.79 6.84a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z'),
  mic: svg('M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z'),
  vol: svg('M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z'),
  gear: svg('M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z'),
};
const hue = s => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const artStyle = t => { const h = hue(t.artist + t.title), g = `linear-gradient(135deg,hsl(${h} 65% 46%),hsl(${(h + 50) % 360} 70% 20%))`, u = coverUrl(t); return u ? `background:url('${esc(u)}') center/cover,${g}` : `background:${g}`; }; // si la imagen falla, queda el degradado
const artHtml = (t, cls = '') => `<div class="art ${cls}" style="${artStyle(t)}">${coverUrl(t) ? '' : esc((t.title || '?').trim().charAt(0).toUpperCase())}</div>`;
/* Metadatos abiertos (como el plugin oficial de Spotube): MusicBrainz + Cover Art Archive + ListenBrainz. Solo identifican; el audio lo resuelve otra fuente. */
const mbTrack = x => {
  const rel = (x.releases || []).find(r => r.status === 'Official') || (x.releases || [])[0];
  const artist = (x['artist-credit'] || []).map(a => a.name + (a.joinphrase || '')).join('').trim();
  const tag = (x.tags || []).slice().sort((a, b) => b.count - a.count)[0];
  return { id: 'mb_' + x.id, title: x.title, artist: artist || 'Artista desconocido', album: rel?.title || 'Sencillo', source: 'musicbrainz', mbid: x.id, blob: null, plays: 0,
    year: parseInt(rel?.date) || undefined, genre: tag?.name, cover: rel ? `https://coverartarchive.org/release/${rel.id}/front-250` : undefined };
};
async function loadLb() { // lo más escuchado de la semana en ListenBrainz (comunidad abierta)
  if (S.lb) return S.lb;
  try {
    const r = await fetch('https://api.listenbrainz.org/1/stats/sitewide/recordings?count=20&range=this_week'); if (!r.ok) throw new Error('lb');
    S.lb = ((await r.json()).payload?.recordings || []).filter(x => x.track_name && x.artist_name).map(x => ({ id: 'mb_' + (x.recording_mbid || x.track_name + x.artist_name), title: x.track_name, artist: x.artist_name,
      album: x.release_name || 'Sencillo', source: 'musicbrainz', mbid: x.recording_mbid, blob: null, plays: 0, cover: x.caa_release_mbid ? `https://coverartarchive.org/release/${x.caa_release_mbid}/front-250` : undefined }));
    addPool(S.lb);
  } catch { S.lb = null; return []; }
  return S.lb;
}
async function fillLb() { if (!$('lb')) return; const l = await loadLb(); if ($('lb')) $('lb').innerHTML = l.length ? '<div class="rail">' + l.map(card).join('') + '</div>' : '<small>Sin conexión con ListenBrainz.</small>'; }
const ytCache = new Map();
const ytItem = x => { const id = typeof x.id === 'string' ? x.id : x.id?.videoId, s = x.snippet || {};
  return { id: 'y_' + id, title: htmlText(s.title || ''), artist: htmlText(s.channelTitle || 'YouTube').replace(/ - Topic$/, ''), album: 'YouTube', source: 'youtube', yt: id, blob: null, plays: 0, cover: s.thumbnails?.medium?.url || s.thumbnails?.default?.url }; };
const HINT = '<div style="margin-top:12px"><small style="display:block">Para buscar CUALQUIER canción (Milo J, Michael Jackson…) activa YouTube. También puedes pegar un enlace.</small><button class="pri" id="ysetup">Activar YouTube</button></div>';
async function resolveYt(t) { // convierte una canción identificada (p. ej. de Spotify) en su versión oficial de YouTube
  if (!S.ytKey) return toast('Para reproducirla desde YouTube añade tu clave gratuita (Biblioteca → YouTube), o importa el archivo.');
  toast('Buscando la versión oficial en YouTube…');
  try {
    const r = (await SOURCES.youtube.search(t.artist + ' ' + t.title))[0];
    if (!r) return toast('No encontré esa canción en YouTube.');
    Object.assign(t, { yt: r.yt, cover: t.cover || r.cover }); await DB.put(t); (cur() === t ? load() : playQueue([t.id], 0));
  } catch { toast('No se pudo buscar en YouTube. Revisa tu clave y tu conexión.'); }
}
const dataCache = new WeakMap();
function nativeCover(t) { // la notificación nativa recibe la portada como data: (local) o URL https
  if (t.coverBlob) {
    if (dataCache.has(t.coverBlob)) return dataCache.get(t.coverBlob);
    dataCache.set(t.coverBlob, '');
    if (typeof createImageBitmap === 'function') createImageBitmap(t.coverBlob).then(bm => {
      const c = document.createElement('canvas'); c.width = c.height = 256; c.getContext('2d').drawImage(bm, 0, 0, 256, 256);
      dataCache.set(t.coverBlob, c.toDataURL('image/jpeg', .8)); if (cur() === t) notifyNative();
    }).catch(() => {});
    return '';
  }
  return S.cfg.saver ? '' : https(t.cover) || '';
}
let notifWarned = false;
function notifyNative() { const t = cur(); try {
    if (t) window.AuraNative?.state(t.title, t.artist, !audio.paused, nativeCover(t));
    if (t && !notifWarned && window.AuraNative?.notifOk && !window.AuraNative.notifOk()) { notifWarned = true; toast('Activa las notificaciones de AURA (Ajustes → Controles en notificación) para ver los controles.'); }
  } catch { /* sin puente nativo */ } }
const cur = () => byId(S.queue[S.idx]);

/* ---------- Fuentes de Internet (MusicSource): solo catálogos que permiten streaming ---------- */
const audiusTrack = x => ({ id: 'a_' + x.id, title: x.title, artist: x.user?.name, album: 'Audius', source: 'audius', blob: null, plays: 0,
  cover: x.artwork?.['480x480'] || x.artwork?.['150x150'], stream: `https://api.audius.co/v1/tracks/${encodeURIComponent(x.id)}/stream?app_name=AURA` });
async function loadTrending() { // descubrimiento: tendencias abiertas de Audius
  if (!$('trend')) return;
  try {
    if (!S.trend) {
      const r = await fetch('https://api.audius.co/v1/tracks/trending?limit=15&app_name=AURA'); if (!r.ok) throw new Error('trend');
      S.trend = ((await r.json()).data || []).filter(x => x.is_streamable !== false).map(audiusTrack).filter(t => t.title && t.artist);
      if (ytOn() && S.ytKey) try { const yr = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet&chart=mostPopular&videoCategoryId=10&maxResults=10&key=${encodeURIComponent(S.ytKey)}`); if (yr.ok) S.trend = ((await yr.json()).items || []).map(ytItem).concat(S.trend); } catch { /* sin YouTube */ }
    }
    S.web = S.trend; if ($('trend')) { addPool(S.trend); $('trend').innerHTML = S.trend.length ? '<div class="rail">' + S.trend.map(card).join('') + '</div>' : '<small>Sin tendencias ahora.</small>'; }
  } catch { if ($('trend')) $('trend').innerHTML = '<small>Sin conexión: no se pueden cargar las tendencias.</small>'; }
}
const SOURCES = {
  musicbrainz: { // Metadatos abiertos: identifica la canción (álbum, año, portada). Su audio se resuelve al tocarla
    async search(q) {
      const r = await fetch('https://musicbrainz.org/ws/2/recording?fmt=json&limit=15&query=' + encodeURIComponent(q)); if (!r.ok) throw new Error('mb');
      return ((await r.json()).recordings || []).filter(x => x.title && (x.releases || []).length).map(mbTrack);
    } },
  itunes: { // Apple: catálogo de millones de canciones con portada, álbum, género y año; audio = vista previa oficial de 30 s
    async search(q) { const d = await itJson('https://itunes.apple.com/search?media=music&entity=song&limit=15&term=' + encodeURIComponent(q)); return (d.results || []).filter(x => x.trackName && x.previewUrl).map(itunesTrack); } },
  youtube: { // YouTube Data API (clave gratuita del usuario) o enlace pegado; solo videos incrustables
    async search(q) {
      if (!ytOn()) return [];
      const m = q.match(/(?:youtu\.be\/|[?&]v=|\/embed\/|\/shorts\/|\/live\/)([\w-]{11})/) || (/^(?=.*[\d_-])[\w-]{11}$/.test(q) ? [0, q] : null);
      if (m) {
        let meta = {}; try { const r = await fetch('https://www.youtube.com/oembed?format=json&url=' + encodeURIComponent('https://www.youtube.com/watch?v=' + m[1])); if (r.ok) meta = await r.json(); } catch { /* sin metadatos */ }
        return [{ id: 'y_' + m[1], title: meta.title || 'Video de YouTube', artist: (meta.author_name || 'YouTube').replace(/ - Topic$/, ''), album: 'YouTube', source: 'youtube', yt: m[1], blob: null, plays: 0, cover: meta.thumbnail_url || `https://i.ytimg.com/vi/${m[1]}/mqdefault.jpg` }];
      }
      if (!S.ytKey) return [];
      if (ytCache.has(q)) return ytCache.get(q);
      const r = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCategoryId=10&videoEmbeddable=true&videoSyndicated=true&maxResults=12&q=${encodeURIComponent(q)}&key=${encodeURIComponent(S.ytKey)}`);
      if (!r.ok) throw new Error('youtube');
      const out = ((await r.json()).items || []).map(ytItem).filter(t => /^[\w-]{11}$/.test(t.yt || '')); ytCache.set(q, out); return out;
    } },
  audius: { // Audius: plataforma abierta de artistas independientes, API gratuita
    async search(q) {
      const r = await fetch('https://api.audius.co/v1/tracks/search?limit=15&app_name=AURA&query=' + encodeURIComponent(q));
      if (!r.ok) throw new Error('audius');
      return ((await r.json()).data || []).filter(x => x.is_streamable !== false).map(audiusTrack);
    } },
  radio: { // Radio en vivo: directorio abierto radio-browser.info (solo emisoras https)
    async search(q) {
      for (const base of ['https://de1.api.radio-browser.info', 'https://nl1.api.radio-browser.info', 'https://at1.api.radio-browser.info']) {
        try {
          const r = await fetch(`${base}/json/stations/search?name=${encodeURIComponent(q)}&hidebroken=true&limit=10&order=votes&reverse=true`);
          if (!r.ok) continue;
          return (await r.json()).filter(s => s.name && https(s.url_resolved)).map(s => ({ id: 'r_' + s.stationuuid, title: s.name.trim(), artist: 'Radio en vivo' + (s.country ? ' · ' + s.country : ''),
            album: (s.tags || '').split(',')[0] || 'Radio', source: 'radio', live: true, blob: null, plays: 0, cover: s.favicon, stream: s.url_resolved }));
        } catch { /* probar el siguiente servidor */ }
      }
      throw new Error('radio');
    } },
  jamendo: { // Jamendo: música Creative Commons; requiere un client_id gratuito
    async search(q) {
      if (!S.jamendoId) return [];
      const r = await fetch(`https://api.jamendo.com/v3.0/tracks/?format=json&limit=15&audioformat=mp32&include=musicinfo&search=${encodeURIComponent(q)}&client_id=${encodeURIComponent(S.jamendoId)}`);
      if (!r.ok) throw new Error('jamendo');
      return ((await r.json()).results || []).map(x => { const mi = x.musicinfo || {};
        return { id: 'j_' + x.id, title: x.name, artist: x.artist_name, album: x.album_name || 'Jamendo', source: 'jamendo', blob: null, plays: 0, cover: x.image, stream: x.audio,
          dlOk: x.audiodownload_allowed === true, dlUrl: x.audiodownload, genre: mi.tags?.genres?.[0], acoustic: mi.acousticelectric, voice: mi.vocalinstrumental, speed: mi.speed }; });
    } },
};
async function webSearch(q) { // los resultados aparecen según responde cada fuente (una lenta no bloquea a las demás)
  const out = []; let ok = false, pending = Object.keys(SOURCES).length;
  const paint = () => {
    const box = $('webres'); if (!box || $('q').value.trim() !== q) return;
    const sorted = out.filter(t => t.title && t.artist && (https(t.stream) || t.yt || t.mbid)).map(t => [t, score(t, q) + (t.yt ? .3 : 0)]).sort((a, b) => b[1] - a[1]).map(x => x[0]);
    const rank = t => t.yt ? 4 : t.stream ? 3 : t.mbid ? 1 : 2, best = new Map(); // un solo resultado por canción: el que tiene mejor audio
    for (const t of sorted) { const k = trackKey(t); if (!best.has(k) || rank(t) > rank(best.get(k))) best.set(k, t); }
    S.web = sorted.filter(t => best.get(trackKey(t)) === t);
    box.innerHTML = '<h3>En Internet</h3>' + (S.web.map(t => row(t)).join('') || `<small>${pending ? 'Buscando…' : ok ? 'Sin resultados en Internet.' : 'Sin conexión o la fuente no responde.'}</small>`) + (!ytOn() || S.ytKey ? '' : HINT);
  };
  await Promise.all(Object.values(SOURCES).map(s => s.search(q).then(r => { out.push(...r); ok = true; }, () => { /* fuente caída u offline */ }).then(() => { pending--; paint(); })));
}
const save = () => Promise.all([DB.set('favs', [...S.favs]), DB.set('history', S.history.slice(-500)), DB.set('playlists', S.playlists)]);

/* ---------- Importación ---------- */
function parseName(name) {
  const base = name.replace(/\.[^.]+$/, '').replace(/_/g, ' ');
  const m = base.split(/\s+-\s+/);
  return m.length > 1 ? { artist: m[0].trim(), title: m.slice(1).join(' - ').trim() } : { artist: 'Artista desconocido', title: base.trim() };
}
async function id3(f) { // lee título, artista, álbum y portada de MP3 con ID3v2.3/2.4
  const out = {};
  try {
    const b = new Uint8Array(await f.slice(0, 2e6).arrayBuffer());
    if (b[0] !== 0x49 || b[1] !== 0x44 || b[2] !== 0x33 || b[3] < 3) return out;
    const end = Math.min(10 + ((b[6] << 21) | (b[7] << 14) | (b[8] << 7) | b[9]), b.length), v = new DataView(b.buffer);
    const txt = (x, enc = x[0]) => new TextDecoder(['iso-8859-1', 'utf-16le', 'utf-16be', 'utf-8'][enc] || 'utf-8').decode(x.subarray(1)).replace(/\0/g, '').trim();
    for (let p = 10; p + 10 < end && b[p];) {
      const id = String.fromCharCode(...b.subarray(p, p + 4)), fs = b[3] === 4 ? (b[p+4] << 21) | (b[p+5] << 14) | (b[p+6] << 7) | b[p+7] : v.getUint32(p + 4);
      const body = b.subarray(p + 10, p + 10 + fs); if (p + 10 + fs > b.length) break; p += 10 + fs;
      if (id === 'TIT2') out.title = txt(body); else if (id === 'TPE1') out.artist = txt(body); else if (id === 'TALB') out.album = txt(body);
      else if (id === 'TCON') out.genre = txt(body).replace(/^\(\d+\)/, '') || undefined; else if (id === 'TKEY') out.key = txt(body);
      else if (id === 'TDRC' || id === 'TYER') out.year = parseInt(txt(body).slice(0, 4)) || undefined; else if (id === 'TBPM') out.bpm = Math.round(parseFloat(txt(body))) || undefined;
      else if (id === 'APIC' && !out.cover) {
        let i = 1; while (body[i]) i++; const mime = String.fromCharCode(...body.subarray(1, i)); i += 2;
        if (body[0] === 1 || body[0] === 2) { while (i + 1 < body.length && (body[i] || body[i + 1])) i += 2; i += 2; } else { while (body[i]) i++; i++; }
        const type = /^image\/(jpeg|png|webp)$/.test(mime) ? mime : 'image/jpeg';
        if (i < body.length) out.cover = new Blob([body.slice(i)], { type });
      }
    }
  } catch { /* sin etiquetas: se usa el nombre del archivo */ }
  return out;
}
async function importFiles(files) {
  let n = 0;
  for (const f of files) {
    if (!f.type.startsWith('audio/') && !/\.(mp3|m4a|aac|flac|wav|ogg|opus)$/i.test(f.name)) { toast('Formato no compatible: ' + f.name); continue; }
    const nm = parseName(f.name), tag = f.type === 'audio/mpeg' || /\.mp3$/i.test(f.name) ? await id3(f) : {};
    const artist = tag.artist || nm.artist, title = tag.title || nm.title, key = trackKey({ artist, title });
    const ex = S.tracks.find(x => !x.blob && trackKey(x) === key);
    const t = ex ? Object.assign(ex, { blob: f, source: 'local', coverBlob: tag.cover || ex.coverBlob, genre: tag.genre, year: tag.year, bpm: tag.bpm, key: tag.key }) : { id: 'l_' + f.name + '_' + f.size, title, artist, album: tag.album || 'Local', coverBlob: tag.cover, genre: tag.genre, year: tag.year, bpm: tag.bpm, key: tag.key, blob: f, source: 'local', added: Date.now(), plays: 0 };
    const id = t.id;
    try { await DB.put(t); S.tracks = S.tracks.filter(x => x.id !== id).concat(t); n++; }
    catch { toast('No se pudo guardar. ¿Almacenamiento lleno?'); break; }
  }
  if (n) { toast(n + ' canciones importadas'); render(); }
}

/* ---------- Reproductor ---------- */
function playQueue(ids, i) { S.queue = ids.filter(id => playable(byId(id))); S.idx = i; load(); }
function prefetchNext() {
  if (S.cfg.saver) return;
  const n = byId(S.queue[S.idx + 1]);
  if (n && !n.blob && !n.yt && !n.live && https(n.stream)) PF.src = n.stream;
}
const triedLyrics = new Set();
const cleanTitle = t => String(t.title).replace(/\([^)]*\)|\[[^\]]*\]/g, '').replace(/\b(official|video|audio|lyrics?|hd|4k)\b/gi, '').replace(new RegExp('^' + String(t.artist).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*[-–]\\s*', 'i'), '').replace(/\s+/g, ' ').trim();
async function fetchLyrics(t) { // opcional: letras sincronizadas de LRCLIB (base abierta); solo si el usuario lo activa
  if (!S.cfg.lrclib || t.lyrics || t.live || triedLyrics.has(t.id)) return;
  triedLyrics.add(t.id);
  try {
    const r = await fetch('https://lrclib.net/api/search?track_name=' + encodeURIComponent(cleanTitle(t)) + '&artist_name=' + encodeURIComponent(t.artist));
    if (!r.ok) return;
    const hit = (await r.json()).find(x => x.syncedLyrics); if (!hit) return;
    t.lyrics = hit.syncedLyrics; lyrFor = null; if (S.tracks.includes(t)) DB.put(t).catch(() => {});
    if (cur() === t) showLyrics();
  } catch { /* sin letra */ }
}
async function load() {
  const t = cur(); if (!t) return;
  audio.pause(); audio = t.blob ? A[1] : t.yt ? YTA : A[0]; if (t.blob) initEq(); applyVol(); lastT = 0;
  if (audio === YTA) $('full').hidden = false;
  applyRate();
  placeYt();
  if (S.url) URL.revokeObjectURL(S.url);
  if (!t.blob && !t.yt && t.itunes && !t.stream) { await resolvePreview(t); if (!t.stream) { toast('Sin vista previa disponible.'); return; } }
  if (t.blob) { S.url = URL.createObjectURL(t.blob); audio.src = S.url; } else if (t.yt) { S.url = null; try { await YTA.load(t.yt); } catch { return; } } else { S.url = null; audio.src = t.stream; }
  if (!S.tracks.includes(t) && !S.tracks.some(x => x.id === t.id)) { S.tracks.push(t); DB.put(t).catch(() => {}); }
  try { await audio.play(); } catch { toast('No se puede reproducir este archivo.'); }
  t.plays++; DB.put(t); S.history.push({ id: t.id, at: Date.now() }); save(); updatePlayer();
  prefetchNext(); fetchLyrics(t);
}
function next(auto) {
  if (!S.queue.length) return;
  if (auto && S.sleepEnd) { S.sleepEnd = false; S.sleepI = 0; $('bSleep').lastChild.textContent = ' Dormir'; return toast('Temporizador: la música se detuvo al terminar la canción.'); }
  if (!auto && cur() && audio.currentTime < 10) S.stats.skips[cur().id] = (S.stats.skips[cur().id] || 0) + 1;
  if (auto && S.repeat === 2) return load();
  if (S.shuffle) S.idx = Math.floor(Math.random() * S.queue.length);
  else if (S.idx + 1 < S.queue.length) S.idx++;
  else if (S.repeat === 1) S.idx = 0; else if (S.cfg.smart && smartAppend()) S.idx++; else if (!auto) S.idx = 0; else return updatePlayer();
  load();
}
const prev = () => { if (audio.currentTime > 3) audio.currentTime = 0; else { S.idx = Math.max(0, S.idx - 1); load(); } };
const toggle = () => audio.paused ? audio.play().catch(() => {}) : audio.pause();
function updatePlayer() {
  const t = cur(); $('mini').hidden = !t; if (!t) return;
  notifyNative();
  showLyrics(); renderExtras(t); placeYt();
  document.querySelectorAll('[data-id]').forEach(e => e.classList.toggle('now', e.dataset.id === t.id)); $('full').classList.toggle('paused', audio.paused);
  $('mMeta').innerHTML = `<b>${esc(t.title)}</b><small>${esc(t.artist)}</small>`;
  ['mArt', 'fArt', 'fbg'].forEach(i => { $(i).setAttribute('style', artStyle(t)); if (i !== 'fbg') $(i).textContent = coverUrl(t) ? '' : (t.title || '?').trim().charAt(0).toUpperCase(); });
  const pv = !!(t.preview && !t.yt && !t.blob); $('fNote').textContent = pv ? 'Vista previa de 30 s del catálogo oficial' : ''; $('bFull').hidden = !pv;
  $('fTitle').textContent = t.title; $('fArtist').textContent = t.artist + ' · ' + t.album;
  $('bFav').innerHTML = S.favs.has(t.id) ? ICON.heartOn : ICON.heart; $('bFav').classList.toggle('on-act', S.favs.has(t.id));
  const ic = audio.paused ? ICON.play : ICON.pause; $('mPlay').innerHTML = ic; $('bPlay').innerHTML = ic;
  $('bShuf').classList.toggle('on-act', S.shuffle); $('bRep').classList.toggle('on-act', !!S.repeat); $('bRep').classList.toggle('one', S.repeat === 2);
  $('queueList').innerHTML = '<h3>Reproduciendo ahora</h3><button id="qclr">Limpiar cola</button>' + S.queue.map((id, i) => {
    const q = byId(id); return q ? (i === S.idx + 1 ? '<h3>Próximamente</h3>' : '') + `<div class="row" data-q="${i}"><div class="meta"><b>${i === S.idx ? '▶ ' : ''}${esc(q.title)}</b><small>${esc(q.artist)}</small></div><button data-up="${i}" aria-label="Subir">↑</button><button data-dn="${i}" aria-label="Bajar">↓</button><button data-rm="${i}" aria-label="Quitar de la cola">✕</button></div>` : '';
  }).join('');
}
const onAudioError = () => toast(cur()?.stream ? 'No se pudo reproducir. ¿Tienes Internet?' : 'Archivo dañado o no compatible.');
const onTime = () => {
  const d = audio.currentTime - lastT; if (d > 0 && d < 2) S.stats.secs += d; lastT = audio.currentTime; fadeVol(); syncLyrics();
  $('tCur').textContent = fmt(audio.currentTime); $('tDur').textContent = isFinite(audio.duration) ? fmt(audio.duration) : (audio.duration ? 'EN VIVO' : '0:00');
  if (audio.duration) $('seek').value = audio.currentTime / audio.duration * 1000;
  const pct = audio.duration && isFinite(audio.duration) ? audio.currentTime / audio.duration * 100 : 0;
  $('seek').style.setProperty('--p', pct + '%'); $('mbar').firstElementChild.style.width = pct + '%';
};
A.forEach(el => {
  el.onplay = el.onpause = () => { if (el === audio) { updatePlayer(); saveStats(); } };
  el.onended = () => { if (el === audio) next(true); };
  el.onerror = () => { if (el === audio) onAudioError(); };
  el.ontimeupdate = () => { if (el === audio) onTime(); };
});
$('seek').oninput = e => { if (audio.duration) audio.currentTime = e.target.value / 1000 * audio.duration; e.target.style.setProperty('--p', e.target.value / 10 + '%'); };
$('vol').oninput = e => { S.vol = e.target.value / 100; applyVol(); e.target.style.setProperty('--p', e.target.value + '%'); };
$('mPlay').onclick = $('bPlay').onclick = toggle;
$('mNext').onclick = $('bNext').onclick = () => next(false);
$('bPrev').onclick = prev;
$('bShuf').onclick = () => { S.shuffle = !S.shuffle; updatePlayer(); };
$('bRep').onclick = () => { S.repeat = (S.repeat + 1) % 3; updatePlayer(); };
$('bFav').onclick = () => { const t = cur(); if (!t) return; S.favs.has(t.id) ? S.favs.delete(t.id) : S.favs.add(t.id); save(); updatePlayer(); };
$('bQueue').onclick = () => $('queueList').scrollIntoView({ behavior: 'smooth' });
$('mini').onclick = e => { if (!e.target.closest('button')) ($('full').hidden = false, placeYt()); };
$('fClose').onclick = () => ($('full').hidden = true, placeYt());
$('queueList').onclick = e => {
  const rm = e.target.closest('[data-rm]'), q = e.target.closest('[data-q]'), up = e.target.closest('[data-up]'), dn = e.target.closest('[data-dn]'), cl = e.target.closest('#qclr');
  const mv = (i, j) => { if (j < 0 || j >= S.queue.length) return; [S.queue[i], S.queue[j]] = [S.queue[j], S.queue[i]]; if (S.idx === i) S.idx = j; else if (S.idx === j) S.idx = i; updatePlayer(); };
  if (up) mv(+up.dataset.up, +up.dataset.up - 1); else if (dn) mv(+dn.dataset.dn, +dn.dataset.dn + 1);
  else if (cl) { S.queue = S.queue.slice(S.idx, S.idx + 1); S.idx = 0; updatePlayer(); } else if (rm) { const i = +rm.dataset.rm; S.queue.splice(i, 1); if (i < S.idx) S.idx--; updatePlayer(); }
  else if (q) { S.idx = +q.dataset.q; load(); }
};
if ('mediaSession' in navigator) {
  const ms = navigator.mediaSession;
  ms.setActionHandler('play', toggle); ms.setActionHandler('pause', toggle);
  ms.setActionHandler('nexttrack', () => next(false)); ms.setActionHandler('previoustrack', prev);
}
window.AURA = { pip: on => document.body.classList.toggle('pip', !!on), act: k => ({ prev, toggle, next: () => next(false) })[k]?.(), back: () => { if (!$('full').hidden) { ($('full').hidden = true, placeYt()); return true; } return false; } };

function renderExtras(t) {
  const f = [['BPM', t.bpm], ['Tonalidad', t.key], ['Género', t.genre], ['Año', t.year], ['Sonido', t.acoustic], ['Voz', t.voice], ['Ritmo', t.speed]].filter(x => x[1]);
  $('dna').innerHTML = '<h3>Song DNA</h3>' + f.map(([k, v]) => `<small>${k}: ${esc(v)}</small>`).join(' · ') + '<small style="display:block">Energía, bailabilidad y valence: datos no disponibles.</small>';
  const rel = recommend(t, 5);
  $('rel').innerHTML = rel.length ? '<h3>Relacionado</h3>' + rel.map(x => `<div class="row" data-r="${esc(x.id)}"><div class="meta"><b>${esc(x.title)}</b><small>${esc(x.artist)}</small></div></div>`).join('') : '';
}
$('rel').onclick = e => { const r = e.target.closest('[data-r]'); if (r) { S.queue.push(r.dataset.r); S.idx = S.queue.length - 1; load(); } };
$('bRadio').onclick = async () => {
  const t = cur(); if (!t) return;
  let ids = recommend(t, 25).map(x => x.id);
  if (ids.length < 5 && ytOn() && S.ytKey) { try { const r = (await SOURCES.youtube.search(t.artist)).filter(x => x.yt !== t.yt); S.pool.push(...r); ids = ids.concat(r.map(x => x.id)); } catch { /* sin YouTube */ } }
  if (!ids.length) return toast('Aún no hay canciones parecidas. Con YouTube activado se crean desde el artista.');
  S.queue = [t.id, ...ids]; S.idx = 0; updatePlayer(); toast('Radio creada: ' + ids.length + ' canciones.');
};
let tx = 0, ty = 0;
$('full').addEventListener('touchstart', e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
$('full').addEventListener('touchend', e => {
  const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
  if (dy > 120 && Math.abs(dx) < 60 && $('full').scrollTop === 0) ($('full').hidden = true, placeYt());
  else if (Math.abs(dx) > 90 && Math.abs(dy) < 50 && e.target.closest('#fArt')) dx < 0 ? next(false) : prev();
});

/* ---------- Letras (.lrc) y guardado offline ---------- */
function parseLrc(txt) {
  const out = [];
  for (const ln of String(txt).split(/\r?\n/)) {
    const tags = [...ln.matchAll(/\[(\d+):(\d+(?:\.\d+)?)\]/g)], text = ln.replace(/\[[^\]]*\]/g, '').trim();
    if (!tags.length) { if (text) out.push({ t: null, text }); continue; }
    tags.forEach(m => out.push({ t: +m[1] * 60 + parseFloat(m[2]), text }));
  }
  return out.some(l => l.t !== null) ? out.filter(l => l.t !== null).sort((a, b) => a.t - b.t) : out;
}
let lyr = [], lyrIdx = -1, lyrFor = null;
function showLyrics() {
  const t = cur(); if (!t || lyrFor === t.id + (t.lyrics || '').length) return;
  lyrFor = t.id + (t.lyrics || '').length; lyr = t.lyrics ? parseLrc(t.lyrics) : []; lyrIdx = -1;
  $('lyr').innerHTML = lyr.length ? lyr.map((l, i) => `<div class="ll" data-i="${i}">${esc(l.text) || '♪'}</div>`).join('') : '<small>Sin letra. Importa un archivo .lrc que tengas.</small>';
}
function syncLyrics() {
  if ($('lyr').hidden || !lyr.length || lyr[0].t === null) return;
  let i = -1; while (i + 1 < lyr.length && lyr[i + 1].t <= audio.currentTime) i++;
  if (i === lyrIdx) return; lyrIdx = i;
  $('lyr').querySelectorAll('.cur').forEach(x => x.classList.remove('cur'));
  const el = $('lyr').querySelector(`[data-i="${i}"]`); if (el) { el.classList.add('cur'); el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
}
$('bLyr').onclick = () => { $('lyr').hidden = !$('lyr').hidden; lyrIdx = -1; };
$('bKar').onclick = () => { $('full').classList.toggle('karaoke'); $('lyr').hidden = false; lyrIdx = -1; };
$('bLrc').onclick = () => $('lrcPicker').click();
$('lyr').onclick = e => { const l = e.target.closest('.ll'); if (l && lyr[+l.dataset.i]?.t != null) audio.currentTime = lyr[+l.dataset.i].t; };
$('lrcPicker').onchange = async e => {
  const f = e.target.files[0], t = cur(); e.target.value = '';
  if (!f || !t) return;
  if (f.size > 5e5) return toast('Archivo de letra demasiado grande.');
  t.lyrics = await f.text(); lyrFor = null;
  if (S.tracks.includes(t)) DB.put(t).catch(() => toast('No se pudo guardar la letra.'));
  showLyrics(); $('lyr').hidden = false; toast('Letra importada.');
};
$('bOff').onclick = () => { const t = cur(); if (t) startDl(t); };

const DL = new Map(), mb = n => (n / 1048576).toFixed(1) + ' MB';
async function startDl(t) {
  if (t.blob) return toast('Ya está guardada en tu teléfono.');
  if (t.source !== 'jamendo') return toast('Solo se puede guardar offline música Jamendo (Creative Commons).');
  if (!t.dlOk || !https(t.dlUrl)) return toast('El artista no permite descargar esta canción.');
  let d = DL.get(t.id); if (!d) { d = { t, chunks: [], got: 0, total: 0 }; DL.set(t.id, d); }
  d.state = 'run'; d.ctl = new AbortController(); toast('Descargando… (Biblioteca → Descargas)');
  try {
    const r = await fetch(t.dlUrl, { signal: d.ctl.signal, headers: d.got ? { Range: 'bytes=' + d.got + '-' } : {} });
    if (!r.ok) throw new Error('http');
    if (d.got && r.status !== 206) { d.chunks = []; d.got = 0; }
    d.total = d.got + (+r.headers.get('content-length') || 0);
    const rd = r.body.getReader();
    for (;;) {
      const { done, value } = await rd.read(); if (done) break;
      d.chunks.push(value); d.got += value.length;
      const el = $('dlp_' + t.id); if (el) el.textContent = d.total ? Math.round(d.got / d.total * 100) + '%' : mb(d.got);
    }
    t.blob = new Blob(d.chunks, { type: 'audio/mpeg' }); await DB.put(t); DL.delete(t.id); toast('Guardada: ' + t.title);
  } catch { if (d.state === 'run') { d.state = 'err'; toast('Descarga fallida. Revisa la conexión y el espacio libre.'); } }
  if (S.tab === 'lib' && !S.plOpen) render();
}
function dlHtml() {
  const saved = S.tracks.filter(t => t.blob && t.stream), used = S.tracks.reduce((n, t) => n + (t.blob?.size || 0), 0);
  const act = [...DL.values()].map(d => `<div class="row"><div class="meta"><b>${esc(d.t.title)}</b><small>${{ run: 'Descargando', pause: 'En pausa', err: 'Error' }[d.state] || ''} · <span id="dlp_${esc(d.t.id)}">${d.total ? Math.round(d.got / d.total * 100) + '%' : mb(d.got)}</span></small></div><button data-dlp="${esc(d.t.id)}" aria-label="Pausar o continuar">${d.state === 'run' ? '⏸' : '▶'}</button><button data-dlc="${esc(d.t.id)}" aria-label="Cancelar">✕</button></div>`).join('');
  return `<h3>Descargas · ${mb(used)} usados</h3>` + ((act + saved.map(t => `<div class="row"><div class="meta"><b>${esc(t.title)}</b><small>${esc(t.artist)} · ${mb(t.blob.size)}</small></div><button data-dld="${esc(t.id)}" aria-label="Eliminar descarga">🗑</button></div>`).join('')) || '<small>Sin descargas. En el reproductor usa "Guardar offline" (Jamendo).</small>');
}

/* ---------- Vistas ---------- */
const tagOf = t => t.blob ? 'Local' : t.yt ? 'YouTube' : t.live ? 'En vivo' : t.preview ? (S.cfg.previews ? 'Preview 30 s' : 'Catálogo') : t.stream ? 'Internet' : t.mbid ? 'Catálogo' : 'Sin audio';
const row = (t, extra = '') => `<div class="row${cur()?.id === t.id ? ' now' : ''}" data-id="${esc(t.id)}">${artHtml(t)}<div class="meta"><b>${esc(t.title)}</b><small>${esc(t.artist)} · ${esc(t.album)}</small></div><span class="tag${t.blob || t.yt || t.stream || t.itunes || t.mbid ? '' : ' off'}">${tagOf(t)}</span>${S.favs.has(t.id) ? ICON.heartOn : ''}${extra}</div>`;
const byIds = ids => ids.map(id => S.tracks.find(t => t.id === id)).filter(Boolean);
const MOODRE = { chill: [/ambient|chill|acoustic|classical|jazz|lo-?fi|folk/i, 0, 100], energy: [/rock|dance|electro|metal|hip|house|techno|punk/i, 120, 999], sad: [/blues|sad|ballad|indie/i, 0, 95],
  love: [/r&b|soul|romantic|love|ballad|latin/i, 0, 110], night: [/electro|ambient|chill|jazz|soul/i, 0, 115], 'road trip': [/rock|pop|country|folk|indie/i, 0, 999], workout: [/dance|hip|rock|metal|electro|pop|house/i, 120, 999] };
const moodLocal = q => { const m = MOODRE[q] || MOODRE[q.split(' ')[0]]; return m ? S.tracks.filter(t => playable(t) && (m[0].test(t.genre || '') || (t.bpm && t.bpm >= m[1] && t.bpm <= m[2]))) : []; };
const TILES = '<div class="tiles">' + [['Relajado', 'chill', 140], ['Energético', 'energy', 20], ['Triste', 'sad songs', 220], ['Romántico', 'love songs', 330], ['Noche', 'night drive', 260], ['Viaje', 'road trip', 40],
  ['Entrenar', 'workout', 350], ['Pop', 'pop hits', 300], ['Reggaetón', 'reggaeton', 50], ['Hip hop', 'hip hop', 200], ['Rock', 'rock classics', 0], ['Electrónica', 'electronic', 180]]
  .map(([n, q, h]) => `<button class="tile" data-mood="${q}" style="background:linear-gradient(135deg,hsl(${h} 70% 38%),hsl(${(h + 40) % 360} 70% 17%))">${n}</button>`).join('') + '</div>';
const card = t => `<div class="card${cur()?.id === t.id ? ' now' : ''}" data-id="${esc(t.id)}">${artHtml(t)}<b>${esc(t.title)}</b><small>${esc(t.artist)}</small></div>`;
const rail = (title, list) => list.length ? `<h3>${title}</h3><div class="rail">${list.map(card).join('')}</div>` : '';
const importBtn = '<button class="pri" id="imp">Importar música</button>';
function render() { renderView(); if (S.tab === 'home') { fillCharts(); fillLb(); if (!S.cfg.saver) loadTrending(); } }
function renderView() {
  const v = $('view'), tracks = S.tracks;
  if (S.tab === 'settings') return renderSettings();
  if (S.tab === 'lib' && S.plOpen) return renderPlaylist();
  if (S.tab === 'home') {
    const hr = new Date().getHours(), g = hr < 6 ? 'Buenas noches' : hr < 13 ? 'Buenos días' : hr < 20 ? 'Buenas tardes' : 'Buenas noches';
    const recent = byIds([...new Set(S.history.slice().reverse().map(x => x.id))].slice(0, 12));
    const top = tracks.slice().sort((a, b) => b.plays - a.plays).filter(t => t.plays).slice(0, 10);
    const H = k => !S.cfg.hide.includes(k), last = recent[0] || null, sk = '<div class="rail">' + '<div class="card"><div class="art sk"></div></div>'.repeat(4) + '</div>';
    const because = last ? recommend(last, 10) : [], mix = top[0] ? recommend(top[0], 12) : [];
    v.innerHTML = `<div class="top"><div><small>${g}</small><h1>${esc(S.profile?.name || '')}</h1></div><button class="icon-btn" id="goset" aria-label="Ajustes">${ICON.gear}</button></div>`
      + `<div class="chips"><button class="pri" id="imp">${ICON.plus} Importar música</button>${!ytOn() || S.ytKey ? '' : '<button id="ysetup">Activar YouTube</button>'}<button id="impd">Importar de Spotify</button></div>`
      + (() => { const d = notifState(); return d && (!d.enabled || !d.perm) ? '<div class="banner"><span>Las notificaciones de AURA están desactivadas, por eso no ves los controles de música.</span><button class="pri" id="notif">Activar</button></div>' : ''; })()
      + (last ? `<div class="hero" data-id="${esc(last.id)}">${artHtml(last)}<div class="meta"><small>Continúa escuchando</small><b>${esc(last.title)}</b><small>${esc(last.artist)}</small></div><button aria-label="Reproducir">${ICON.play}</button></div>` : '')
      + (H('charts') ? '<h3>Top global</h3><div id="charts">' + sk + '</div>' : '')
      + (H('lb') ? '<h3>Lo más escuchado esta semana</h3><div id="lb">' + sk + '</div>' : '')
      + (H('trend') ? '<h3>Tendencias</h3><div id="trend">' + (S.cfg.saver ? '<button id="ldtr">Cargar tendencias</button>' : sk) + '</div>' : '')
      + (H('recent') ? rail('Reproducido recientemente', recent.slice(1)) : '') + (H('because') && last ? rail('Porque escuchaste ' + esc(last.title), because) : '')
      + (H('mix') ? rail('Mix para hoy', mix) : '') + (H('top') ? rail('Más reproducidas', top) : '') + (H('favs') ? rail('Favoritos', byIds([...S.favs])) : '')
      + (H('moods') ? '<h3>Explora por ánimo y género</h3>' + TILES : '');
  } else if (S.tab === 'search') {
    v.innerHTML = '<h1>Buscar</h1><div class="sbox">' + ICON.search + '<input type="text" id="q" placeholder="Canciones, artistas, álbumes" autocomplete="off"></div><div id="explore"><h3>Explorar</h3>' + TILES + '</div><div id="res"></div><div id="webres"></div>';
    let wt; $('q').oninput = e => {
      const v = e.target.value.trim(), r = v ? search(tracks, v) : [];
      $('explore').hidden = !!v;
      $('res').innerHTML = r.length ? '<h3>En tu biblioteca</h3>' + r.map(t => row(t)).join('') : ''; $('res').dataset.ids = JSON.stringify(r.map(t => t.id));
      clearTimeout(wt); S.web = [];
      if (v.length < 2) { $('webres').innerHTML = ''; return; }
      $('webres').innerHTML = '<small>Buscando en Internet…</small>'; wt = setTimeout(() => webSearch(v), 500);
    };
  } else {
    v.innerHTML = '<h1>Biblioteca</h1>' + importBtn + ' <button id="goset">⚙ Ajustes</button>' + ' <button id="np">Nueva playlist</button> <button id="exp">Exportar</button>' +
      '<h3>Playlists</h3>' + (S.playlists.map(p => `<div class="row" data-pl="${esc(p.id)}"><div class="meta"><b>${esc(p.name)}</b><small>${p.ids.length} canciones</small></div><button data-dp="${esc(p.id)}" aria-label="Eliminar playlist">🗑</button></div>`).join('') || '<small>Sin playlists.</small>') +
      '<h3>Cuenta</h3><div class="row"><div class="meta"><b>' + esc(S.profile?.name) + '</b><small>Cuenta local · tus datos solo están en este teléfono</small></div></div><button class="pri" id="impd">Importar de Spotify o backup</button> ' + (S.profile?.pin ? '<button id="lock">Bloquear</button> ' : '') + '<button id="jam">Jamendo' + (S.jamendoId ? ' ✓' : '') + '</button> <button id="yt">YouTube' + (S.ytKey ? ' ✓' : '') + '</button> <button id="wipe">Borrar cuenta</button><small style="display:block;margin-top:8px">Spotify → Cuenta → Privacidad → Descargar tus datos. Cuando te llegue el ZIP, elígelo aquí. Se importan playlists, me gusta e historial; el audio no, solo identificación.</small>' + dlHtml() + `<h3>Canciones (${tracks.length})</h3>` + tracks.map(t => row(t, `<button data-aq="${esc(t.id)}" aria-label="Añadir a la cola">⏭</button><button data-add="${esc(t.id)}" aria-label="Añadir a playlist">＋</button><button data-del="${esc(t.id)}" aria-label="Eliminar">🗑</button>`)).join('');
  }
}
$('view').onclick = async e => {
  const g = s => e.target.closest(s);
  if (g('#imp')) return $('picker').click();
  const pidx = (k) => { const x = g('[data-' + k + ']'); return x ? +x.dataset[k] : -1; }, P = S.playlists.find(p => p.id === S.plOpen);
  const swap = (i, j) => { if (P && j >= 0 && j < P.ids.length) { [P.ids[i], P.ids[j]] = [P.ids[j], P.ids[i]]; save(); render(); } };
  if (g('#plback')) { S.plOpen = null; if (S.tab === 'settings') S.tab = 'lib'; return render(); }
  if (g('#goset')) { S.tab = 'settings'; return render(); }
  if (g('#ldtr')) return loadTrending();
  if (P && g('#plplay')) return P.ids.length ? playQueue(P.ids, 0) : toast('Playlist vacía.');
  if (P && g('#plshuf')) return P.ids.length ? playQueue(P.ids.slice().sort(() => Math.random() - .5), 0) : toast('Playlist vacía.');
  if (P && g('#plren')) { const n = prompt('Nuevo nombre', P.name); if (n?.trim()) { P.name = n.trim(); save(); render(); } return; }
  if (P && pidx('pu') >= 0) return swap(pidx('pu'), pidx('pu') - 1);
  if (P && pidx('pd') >= 0) return swap(pidx('pd'), pidx('pd') + 1);
  if (P && pidx('pr') >= 0) { P.ids.splice(pidx('pr'), 1); save(); return render(); }
  const aq = g('[data-aq]'); if (aq) { const t = byId(aq.dataset.aq); if (!playable(t)) return toast('Esa canción no tiene audio.'); S.queue.push(t.id); if (S.idx < 0) { S.idx = 0; load(); } toast('Añadida a la cola.'); return; }
  const dlp = g('[data-dlp]'); if (dlp) { const d = DL.get(dlp.dataset.dlp); if (d.state === 'run') { d.state = 'pause'; d.ctl.abort(); render(); } else startDl(d.t); return; }
  const dlc = g('[data-dlc]'); if (dlc) { const d = DL.get(dlc.dataset.dlc); d.state = 'cancel'; d.ctl.abort(); DL.delete(dlc.dataset.dlc); return render(); }
  const dld = g('[data-dld]'); if (dld) { const t = byId(dld.dataset.dld); t.blob = null; await DB.put(t); return render(); }
  const st = g('[data-th],[data-sv],[data-perf],[data-eq],[data-smart],[data-hide],[data-pv],[data-ac],[data-lrc],[data-yt]');
  if (st) {
    const d = st.dataset, c = S.cfg;
    if (d.th) c.theme = d.th; if (d.pv) c.previews = !c.previews; if (d.ac) c.accent = d.ac; if (d.yt) { c.yt = !ytOn(); if (!c.yt && audio === YTA) audio.pause(); S.trend = null; } if (d.lrc) c.lrclib = !c.lrclib; if (d.sv) c.saver = +d.sv; if (d.perf) c.perf = !c.perf; if (d.smart) c.smart = !c.smart;
    if (d.eq) { c.eq = d.eq; c.eqGains = [...EQ.presets[d.eq]]; applyEq(); }
    if (d.hide) c.hide = c.hide.includes(d.hide) ? c.hide.filter(x => x !== d.hide) : [...c.hide, d.hide];
    applyCfg(); saveCfg(); return render();
  }
  const mood = g('[data-mood]');
  if (mood) { S.tab = 'search'; document.querySelectorAll('nav button').forEach(x => x.classList.toggle('on', x.dataset.t === 'search')); render(); $('q').value = mood.dataset.mood; $('q').oninput({ target: $('q') });
    const ml = moodLocal(mood.dataset.mood); if (ml.length) { $('res').innerHTML = '<h3>Tu mix local</h3>' + ml.map(t => row(t)).join(''); $('res').dataset.ids = JSON.stringify(ml.map(t => t.id)); }
    return; }
  if (g('#impd')) return $('dataPicker').click();
  if (g('#jam')) { const id = prompt('Client ID gratuito de Jamendo (developer.jamendo.com). Vacío para quitarlo:', S.jamendoId); if (id !== null) { S.jamendoId = id.trim(); await DB.set('jamendo', S.jamendoId); toast(S.jamendoId ? 'Jamendo activado.' : 'Jamendo desactivado.'); render(); } return; }
  if (g('#yt') || g('#ysetup')) return ytSetup();
  if (g('#ntest')) {
    try { window.AuraNative.test(); } catch { return toast('Esta función solo existe en la app instalada.'); }
    setTimeout(() => { const d = notifState(); toast(!d ? 'Sin puente nativo.' : d.error ? 'Error: ' + d.error : !d.enabled || !d.perm ? 'Las notificaciones están desactivadas para AURA.' : 'Enviada. Mira la barra de notificaciones.'); if (S.tab === 'settings') render(); }, 900);
    return;
  }
  if (g('#batt')) { try { window.AuraNative.batterySettings(); } catch { toast('Ajustes del teléfono → Batería → AURA → Sin restricciones.'); } return; }
  if (g('#notif')) { try { window.AuraNative.notifSettings(); } catch { toast('Ajustes del teléfono → Apps → AURA → Notificaciones.'); } return; }
  if (g('#lock')) return lock();
  if (g('#wipe')) { if (confirm('Esto borra tu cuenta y TODOS tus datos locales. ¿Seguro?')) { audio.pause(); indexedDB.deleteDatabase('aura'); setTimeout(() => location.reload(), 300); } return; }
  if (g('#exp')) { const b = new Blob([JSON.stringify({ favs: [...S.favs], history: S.history, playlists: S.playlists, tracks: S.tracks.map(({ blob, ...m }) => m) })], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'aura-backup.json'; a.click(); return; }
  if (g('#np')) { const name = prompt('Nombre de la playlist'); if (name?.trim()) { S.playlists.push({ id: 'p_' + Date.now(), name: name.trim(), ids: [] }); save(); render(); } return; }
  const dp = g('[data-dp]'); if (dp) { S.playlists = S.playlists.filter(p => p.id !== dp.dataset.dp); save(); return render(); }
  const add = g('[data-add]'); if (add) {
    if (!S.playlists.length) return toast('Crea una playlist primero.');
    const n = prompt('Playlist:\n' + S.playlists.map((p, i) => (i + 1) + '. ' + p.name).join('\n')); const p = S.playlists[(+n || 0) - 1];
    if (p && !p.ids.includes(add.dataset.add)) { p.ids.push(add.dataset.add); save(); toast('Añadida a ' + p.name); render(); } return;
  }
  const del = g('[data-del]'); if (del) { if (confirm('¿Eliminar de la biblioteca?')) { await DB.del(del.dataset.del); S.tracks = S.tracks.filter(t => t.id !== del.dataset.del); render(); } return; }
  const pl = g('[data-pl]'); if (pl) { S.plOpen = pl.dataset.pl; return render(); }
  const r = g('.row[data-id], .card[data-id], .hero[data-id]'); if (r) {
    const pick = byId(r.dataset.id);
    if (!playable(pick)) return resolveAny(pick);
    const grp = r.closest('.rail, #webres, #trend, #charts'), plIds = S.plOpen ? S.playlists.find(p => p.id === S.plOpen)?.ids || [] : null;
    const ctx = (grp ? [...grp.querySelectorAll('[data-id]')].map(x => x.dataset.id) : plIds ? plIds : S.tab === 'search' ? JSON.parse($('res').dataset.ids || '[]') : S.tracks.map(t => t.id)).filter(id => playable(byId(id)));
    playQueue(ctx, Math.max(0, ctx.indexOf(r.dataset.id)));
  }
};
$('view').oninput = e => {
  const d = e.target.dataset;
  if (d.band !== undefined) { S.cfg.eqGains[+d.band] = +e.target.value; S.cfg.eq = 'Custom'; applyEq(); saveCfg(); }
  else if (e.target.id === 'fade') { S.cfg.fade = +e.target.value; $('fadev').textContent = S.cfg.fade; if (!S.cfg.fade) applyVol(); saveCfg(); }
};
const THEMES = [['auto', 'Automático'], ['amoled', 'AMOLED'], ['dark', 'Oscuro'], ['light', 'Claro']];
const HIDE = [['lb', 'Más escuchado (ListenBrainz)'], ['charts', 'Top global'], ['moods', 'Estados de ánimo'], ['trend', 'Tendencias'], ['recent', 'Continúa escuchando'], ['because', 'Porque escuchaste'], ['mix', 'Mix para hoy'], ['top', 'Más reproducidas'], ['favs', 'Favoritos']];
function renderPlaylist() {
  const p = S.playlists.find(x => x.id === S.plOpen); if (!p) { S.plOpen = null; return render(); }
  $('view').innerHTML = `<button id="plback">← Biblioteca</button><h1>${esc(p.name)}</h1><button class="pri" id="plplay">Reproducir</button> <button id="plshuf">Aleatorio</button> <button id="plren">Renombrar</button>` +
    (p.ids.map((id, i) => { const t = byId(id); return t ? row(t, `<button data-pu="${i}" aria-label="Subir">↑</button><button data-pd="${i}" aria-label="Bajar">↓</button><button data-pr="${i}" aria-label="Quitar">✕</button>`) : ''; }).join('') || '<p>Vacía. Añade canciones con ＋ desde la biblioteca.</p>');
}
function statsHtml() {
  const hc = {}, gc = {}; S.history.forEach(h => { const t = byId(h.id); if (t) hc[t.artist] = (hc[t.artist] || 0) + 1; });
  S.tracks.forEach(t => { if (t.genre && t.plays) gc[t.genre] = (gc[t.genre] || 0) + t.plays; });
  const top = o => Object.entries(o).sort((a, b) => b[1] - a[1]).slice(0, 5), best = S.tracks.slice().sort((a, b) => b.plays - a.plays)[0];
  const line = s => `<small style="display:block">${s}</small>`;
  return '<h3>Estadísticas</h3>' + line(`Reproducciones: ${S.tracks.reduce((n, t) => n + t.plays, 0)} · Minutos escuchados: ${Math.round(S.stats.secs / 60)} · Favoritas: ${S.favs.size}`)
    + line('Más reproducida: ' + (best?.plays ? esc(best.title) : '—')) + line('Artistas: ' + (top(hc).map(a => esc(a[0]) + ' (' + a[1] + ')').join(', ') || '—')) + line('Géneros: ' + (top(gc).map(g => esc(g[0])).join(', ') || 'datos no disponibles'));
}
async function diag() {
  const e = await navigator.storage?.estimate?.().catch(() => null), p = document.createElement('audio');
  const dec = [['MP3', 'audio/mpeg'], ['AAC/M4A', 'audio/mp4'], ['FLAC', 'audio/flac'], ['OGG', 'audio/ogg'], ['OPUS', 'audio/ogg; codecs=opus'], ['WAV', 'audio/wav']].map(([n, m]) => `${n}: ${p.canPlayType(m) || 'no'}`).join(', ');
  return [['Versión', VERSION], ['Canciones indexadas', S.tracks.filter(t => t.blob).length], ['IndexedDB', DB.db ? 'OK' : 'No disponible'], ['Almacenamiento', e ? mb(e.usage) + ' de ' + mb(e.quota) : 'n/d'],
    ['WebView', navigator.userAgent], ['Decodificadores', dec], ['Reproductor', `${audio.paused ? 'en pausa' : 'reproduciendo'}, readyState ${audio.readyState}${audio.error ? ', error ' + audio.error.code : ''}`], ['Puente nativo', window.AuraNative ? 'sí' : 'no'], ['Notificaciones', (() => { const d = notifState(); return d ? `Android ${d.sdk} · permiso ${d.perm ? 'sí' : 'NO'} · activadas ${d.enabled ? 'sí' : 'NO'} · servicio ${d.service ? 'activo' : 'inactivo'}${d.error ? ' · error: ' + d.error : ''}` : 'n/d'; })()]]
    .map(([k, v]) => `<small style="display:block"><b>${k}:</b> ${esc(v)}</small>`).join('');
}
function ytSetup() {
  let g = $('ysheet'); if (!g) { g = document.createElement('div'); g.id = 'ysheet'; document.body.appendChild(g); }
  g.hidden = false;
  g.innerHTML = `<h2>Activar YouTube</h2><p>Gratis, unos 3 minutos y una sola vez. La clave se guarda solo en tu teléfono.</p>
    <ol><li>Abre Google Cloud e inicia sesión. <button id="ygo">Abrir Google Cloud</button></li>
    <li>Crea un proyecto y pulsa <b>Habilitar</b> en "YouTube Data API v3".</li>
    <li>Ve a Credenciales → Crear credenciales → <b>Clave de API</b> y cópiala. <button id="ygo2">Abrir credenciales</button></li><li>Vuelve aquí y toca <b>Pegar</b>:</li></ol>
    <div class="sbox"><input type="text" id="ykey" placeholder="AIza…" value="${esc(S.ytKey)}" autocomplete="off"><button id="ypaste" class="pri">Pegar</button></div>
    <p><button class="pri" id="ysave">Guardar y probar</button> <button id="yclose">Cerrar</button></p>
    <small id="ymsg" style="display:block">Cuota gratuita: unas 100 búsquedas al día.</small>`;
  $('ygo').onclick = () => { try { window.AuraNative.openUrl('https://console.cloud.google.com/apis/library/youtube.googleapis.com'); } catch { toast('Abre console.cloud.google.com en tu navegador.'); } };
  $('ygo2').onclick = () => { try { window.AuraNative.openUrl('https://console.cloud.google.com/apis/credentials'); } catch { toast('Abre console.cloud.google.com/apis/credentials en tu navegador.'); } };
  $('ypaste').onclick = async () => { // pega la clave copiada y la prueba de una vez
    try { const t = (await navigator.clipboard.readText()).trim(); if (!t) throw new Error('vacío'); $('ykey').value = t; $('ysave').click(); }
    catch { toast('Mantén pulsado en el campo y elige Pegar.'); }
  };
  $('yclose').onclick = () => { g.hidden = true; render(); };
  $('ysave').onclick = async () => {
    const k = $('ykey').value.trim(); S.ytKey = k; S.trend = null; ytCache.clear(); await DB.set('ytkey', k);
    if (!k) { $('ymsg').textContent = 'Clave quitada.'; return; }
    $('ymsg').textContent = 'Probando…';
    try {
      const r = await fetch('https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=music&key=' + encodeURIComponent(k)), j = await r.json().catch(() => ({}));
      $('ymsg').textContent = r.ok ? '✓ Funciona. Ya puedes buscar música en YouTube.' : 'Error: ' + String(j.error?.message || r.status).replace(/<[^>]*>/g, '').slice(0, 160);
    } catch { $('ymsg').textContent = 'Sin conexión.'; }
  };
}
function renderSettings() {
  const c = S.cfg, b = (attr, val, label, on) => `<button ${attr}="${val}"${on ? ' class="pri"' : ''}>${label}</button>`;
  $('view').innerHTML = `<button id="plback">← Biblioteca</button><h1>Ajustes</h1>
    <h3>Tema</h3>${THEMES.map(([k, n]) => b('data-th', k, n, c.theme === k)).join(' ')}
    <h3>Color de acento</h3>${Object.entries(ACCENTS).map(([k, [d]]) => `<button class="sw${c.accent === k ? ' sel' : ''}" data-ac="${k}" style="background:${d}" aria-label="${k}"></button>`).join('')}
    <h3>Rendimiento</h3>${b('data-perf', '1', 'Modo rendimiento: ' + (c.perf ? 'sí' : 'no'), c.perf)}<small style="display:block">Quita animaciones, blur y efectos.</small>
    <h3>Modo ahorro</h3>${['Normal', 'Ahorro', 'Ultra ahorro'].map((n, i) => b('data-sv', i, n, c.saver === i)).join(' ')}<small style="display:block">Ahorro: sin portadas de Internet ni tendencias automáticas. Ultra: además sin animaciones.</small>
    <h3>Ecualizador (archivos locales)</h3>${Object.keys(EQ.presets).map(k => b('data-eq', k, k, c.eq === k)).join(' ')}${c.eq === 'Custom' ? ' <button class="pri">Custom</button>' : ''}
    ${EQ.bands.map((f, i) => `<label><small>${f} Hz</small><input type="range" min="-12" max="12" value="${c.eqGains[i]}" data-band="${i}"></label>`).join('')}
    <h3>Fundido entre canciones: <span id="fadev">${c.fade}</span> s</h3><input type="range" id="fade" min="0" max="12" value="${c.fade}">
    <h3>YouTube</h3>${b('data-yt', '1', 'YouTube: ' + (ytOn() ? 'activado' : 'desactivado'), ytOn())}<small style="display:block">Desactivado: no se busca ni se reproduce nada de YouTube y no se carga su reproductor.</small>
    <h3>Vistas previas de 30 s</h3>${b('data-pv', '1', 'Permitir vistas previas: ' + (c.previews ? 'sí' : 'no'), c.previews)}<small style="display:block">Apagado: las canciones solo suenan completas (YouTube, tus archivos y fuentes libres).</small>
    <h3>Letras</h3>${b('data-lrc', '1', 'Buscar letras en línea (LRCLIB): ' + (c.lrclib ? 'sí' : 'no'), c.lrclib)}<small style="display:block">Apagado por defecto. Al activarlo se envía el título y el artista a lrclib.net, una base abierta de letras sincronizadas. También puedes importar tus .lrc.</small>
    <h3>Cola inteligente</h3>${b('data-smart', '1', 'Al terminar la cola: ' + (c.smart ? 'sí' : 'no'), c.smart)}
    <h3>Secciones de Inicio</h3>${HIDE.map(([k, n]) => b('data-hide', k, (c.hide.includes(k) ? 'Oculta: ' : 'Visible: ') + n, !c.hide.includes(k))).join(' ')}
    <h3>Segundo plano</h3><button id="notif">Controles en notificación</button> <button id="batt">Evitar que Android pause la música</button> <button id="ntest">Probar notificación</button>
    <h3>Datos</h3><button id="exp">Exportar biblioteca</button> <button id="impd">Importar backup o Spotify</button>
    ${statsHtml()}<h3>AURA Diagnostics</h3><div id="diag"><small>Cargando…</small></div>`;
  diag().then(h => { if ($('diag')) $('diag').innerHTML = h; });
}
$('picker').onchange = e => { importFiles([...e.target.files]); e.target.value = ''; };
document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.remove('on')); b.classList.add('on'); S.tab = b.dataset.t; S.plOpen = null; render();
});

/* ---------- Importar datos de Spotify / backup AURA ---------- */
const trackKey = t => norm(t.artist) + '|' + norm(t.title);
async function readZip(f) { // lee solo los .json relevantes del ZIP, sin cargarlo entero
  const out = [], tail = new DataView(await f.slice(Math.max(0, f.size - 65557)).arrayBuffer());
  let e = tail.byteLength - 22; while (e >= 0 && tail.getUint32(e, true) !== 0x06054b50) e--;
  if (e < 0) throw new Error('zip');
  const n = tail.getUint16(e + 10, true), cdSize = tail.getUint32(e + 12, true), cdOff = tail.getUint32(e + 16, true);
  const cd = new DataView(await f.slice(cdOff, cdOff + cdSize).arrayBuffer()); let p = 0;
  for (let i = 0; i < n; i++) {
    const m = cd.getUint16(p + 10, true), cs = cd.getUint32(p + 20, true), nl = cd.getUint16(p + 28, true), xl = cd.getUint16(p + 30, true), cl = cd.getUint16(p + 32, true), off = cd.getUint32(p + 42, true);
    const name = new TextDecoder().decode(new Uint8Array(cd.buffer, p + 46, nl)); p += 46 + nl + xl + cl;
    if (!/(Playlist|YourLibrary|StreamingHistory|Streaming_History_Audio)[^/]*\.json$/i.test(name)) continue;
    const lh = new DataView(await f.slice(off, off + 30).arrayBuffer()), start = off + 30 + lh.getUint16(26, true) + lh.getUint16(28, true);
    let blob = f.slice(start, start + cs);
    if (m === 8) blob = await new Response(blob.stream().pipeThrough(new DecompressionStream('deflate-raw'))).blob();
    out.push({ name, data: JSON.parse(await blob.text()) });
  }
  return out;
}
async function importData(files) {
  const docs = [];
  try { for (const f of files) { if (/\.zip$/i.test(f.name)) docs.push(...await readZip(f)); else docs.push({ name: f.name, data: JSON.parse(await f.text()) }); } }
  catch { return toast('No pude leer ese archivo. Elige el ZIP de Spotify o sus archivos .json.'); }
  const have = new Map(S.tracks.map(t => [trackKey(t), t])), fresh = new Set(), r = { pl: 0, fav: 0, hist: 0, tr: 0 };
  const ident = (title, artist, album) => {
    if (!title || !artist) return null;
    const k = trackKey({ title, artist }); let t = have.get(k);
    if (!t) { t = { id: 's_' + k, title: String(title), artist: String(artist), album: String(album || 'Sin álbum'), blob: null, source: 'spotify', added: Date.now(), plays: 0 }; have.set(k, t); S.tracks.push(t); fresh.add(t); r.tr++; }
    return t.id;
  };
  const hist = [];
  for (const { data: d } of docs) {
    if (Array.isArray(d)) for (const x of d) hist.push({ title: x.trackName || x.master_metadata_track_name, artist: x.artistName || x.master_metadata_album_artist_name, album: x.master_metadata_album_album_name, at: Date.parse(x.endTime || x.ts) || 0 });
    else if (Array.isArray(d.playlists)) for (const p of d.playlists) { S.playlists.push({ id: 'p_' + Date.now() + '_' + r.pl++, name: String(p.name || 'Playlist'), ids: (p.items || []).map(i => i.track && ident(i.track.trackName, i.track.artistName, i.track.albumName)).filter(Boolean) }); }
    else if (Array.isArray(d.tracks) && d.tracks[0]?.track !== undefined && d.tracks[0]?.artist !== undefined) for (const x of d.tracks) { const id = ident(x.track, x.artist, x.album); if (id) { S.favs.add(id); r.fav++; } }
    else if (d.favs && d.playlists === undefined) { /* formato desconocido */ }
  }
  for (const { data: d } of docs) if (d.favs && d.tracks && !Array.isArray(d.tracks[0])) { // backup AURA
    const map = new Map(d.tracks.map(t => [t.id, ident(t.title, t.artist, t.album) || t.id]));
    d.favs.forEach(id => S.favs.add(map.get(id) || id)); r.fav += d.favs.length;
    (d.playlists || []).forEach(p => { S.playlists.push({ id: 'p_' + Date.now() + '_' + r.pl++, name: p.name, ids: p.ids.map(i => map.get(i) || i) }); });
    S.history.push(...(d.history || []).map(h => ({ ...h, id: map.get(h.id) || h.id })));
  }
  const cnt = new Map(); hist.forEach(h => { const k = trackKey(h); cnt.set(k, (cnt.get(k) || 0) + 1); });
  const top = new Set([...cnt].sort((a, b) => b[1] - a[1]).slice(0, 300).map(x => x[0]));
  for (const h of hist) if (top.has(trackKey(h))) { const id = ident(h.title, h.artist, h.album); S.history.push({ id, at: h.at }); have.get(trackKey(h)).plays++; fresh.add(have.get(trackKey(h))); r.hist++; }
  S.history.sort((a, b) => a.at - b.at);
  try { for (const t of fresh) await DB.put(t); await save(); } catch { return toast('No se pudo guardar. ¿Almacenamiento lleno?'); }
  toast(`Importado: ${r.pl} playlists, ${r.fav} me gusta, ${r.tr} canciones nuevas, ${r.hist} reproducciones`); render();
}
$('dataPicker').onchange = e => { importData([...e.target.files]); e.target.value = ''; };

/* ---------- Cuenta local ---------- */
async function hash(s) {
  try { return [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode('aura:' + s)))].map(x => x.toString(16).padStart(2, '0')).join(''); }
  catch { return 'b:' + btoa(s); }
}
function gateUI(html) { let g = $('gate'); if (!g) { g = document.createElement('div'); g.id = 'gate'; document.body.appendChild(g); } g.hidden = false; g.innerHTML = html; return g; }
function setup() {
  const g = gateUI('<h1>Crea tu cuenta</h1><p>Vive solo en este teléfono. No se envía nada a Internet.</p><input type="text" id="gn" placeholder="Tu nombre" maxlength="30"><input type="password" id="gp" placeholder="PIN opcional (4 a 8 números)" inputmode="numeric" maxlength="8"><button class="pri" id="go">Crear cuenta</button>');
  $('go').onclick = async () => {
    const name = $('gn').value.trim(), pin = $('gp').value.trim();
    if (!name) return toast('Escribe tu nombre.');
    if (pin && !/^\d{4,8}$/.test(pin)) return toast('El PIN debe tener de 4 a 8 números.');
    S.profile = { name, pin: pin ? await hash(pin) : null, created: Date.now() };
    await DB.set('profile', S.profile); g.hidden = true; render();
  };
}
function lock() {
  const g = gateUI(`<h1>Hola, ${esc(S.profile.name)}</h1><input type="password" id="gp" placeholder="PIN" inputmode="numeric" maxlength="8"><button class="pri" id="go">Entrar</button>`);
  $('go').onclick = async () => { if (await hash($('gp').value.trim()) === S.profile.pin) { g.hidden = true; render(); } else toast('PIN incorrecto.'); };
}

const SLEEP = [0, 15, 30, 60, 'end'];
$('bSleep').onclick = () => { // toca para rotar: apagado → 15 → 30 → 60 min → al terminar la canción
  clearTimeout(S.sleepT); S.sleepEnd = false; S.sleepI = (S.sleepI + 1) % SLEEP.length;
  const v = SLEEP[S.sleepI], b = $('bSleep');
  if (v === 0) { b.lastChild.textContent = ' Dormir'; return toast('Temporizador apagado.'); }
  if (v === 'end') { S.sleepEnd = true; b.lastChild.textContent = ' Al terminar'; return toast('La música se detendrá al terminar esta canción.'); }
  S.sleepT = setTimeout(() => { audio.pause(); S.sleepI = 0; b.lastChild.textContent = ' Dormir'; toast('Temporizador: música detenida.'); }, v * 60000);
  b.lastChild.textContent = ' ' + v + ' min'; toast('La música se detendrá en ' + v + ' minutos.');
};
const RATES = [0.75, 1, 1.25, 1.5, 2];
$('bSpeed').onclick = () => { S.rate = RATES[(RATES.indexOf(S.rate) + 1) % RATES.length]; applyRate(); $('bSpeed').lastChild.textContent = ' ' + S.rate + '×'; toast('Velocidad ' + S.rate + '×'); };
$('bFull').onclick = () => { const t = cur(); if (!t) return; ytOn() && S.ytKey ? resolveYt(t) : toast('Para la canción completa activa YouTube (Biblioteca → YouTube) o importa el archivo.'); };
document.querySelectorAll('[data-i]').forEach(el => el.insertAdjacentHTML('afterbegin', ICON[el.dataset.i] || ''));
$('mPlay').innerHTML = ICON.play; $('bPlay').innerHTML = ICON.play; $('bFav').innerHTML = ICON.heart; $('vol').style.setProperty('--p', '100%');

/* ---------- Arranque ---------- */
(async () => {
  try {
    await DB.open();
    S.tracks = await DB.all();
    S.favs = new Set(await DB.get('favs') || []); S.history = await DB.get('history') || []; S.playlists = await DB.get('playlists') || []; S.profile = await DB.get('profile'); S.jamendoId = await DB.get('jamendo') || ''; S.ytKey = await DB.get('ytkey') || '';
    Object.assign(S.cfg, await DB.get('cfg') || {}); S.stats = Object.assign(S.stats, await DB.get('stats') || {}); applyCfg();
  } catch { toast('No se pudo abrir la base de datos local.'); }
  render();
  if (!S.profile) setup(); else if (S.profile.pin) lock();
})();
